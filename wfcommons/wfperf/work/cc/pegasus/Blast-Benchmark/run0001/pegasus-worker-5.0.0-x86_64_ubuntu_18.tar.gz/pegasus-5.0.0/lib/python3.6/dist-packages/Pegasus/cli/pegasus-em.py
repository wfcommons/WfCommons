#!/usr/bin/env python3


from Pegasus.service.ensembles.commands import main

main()
