#!/usr/bin/env python3


from Pegasus.service.server import main

main()
